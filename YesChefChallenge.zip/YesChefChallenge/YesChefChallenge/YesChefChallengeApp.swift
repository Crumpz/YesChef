//
//  YesChefChallengeApp.swift
//  YesChefChallenge
//
//  Created by Sudowe, Yuki - Student on 9/17/24.
//

import SwiftUI

@main
struct YesChefChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
