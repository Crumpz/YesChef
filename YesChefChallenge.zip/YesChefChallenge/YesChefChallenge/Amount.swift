//
//  Amount.swift
//  YesChefChallenge
//
//  Created by Sudowe, Yuki - Student on 9/17/24.
//

import SwiftUI

struct Amount: View {
    @State private var showText = false
    var body: some View {
        VStack {
            Text("Serves Two People")
            
                        Button(action: {
                            
                            showText.toggle()
                        }) {
                            Text("Serving For Four")
                                .padding()
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                        
                        if showText {
                            Text("Ingredients for 4 servings: BOBA PEARLS: ⅔ cup water, plus more as needed ½ cup dark muscovado sugar, or brown sugar flour, plus more for dusting  BROWN SUGAR SYRUP: 2 cups dark muscovado sugar, or brown sugar 2 cups water BLACK TEA  4 cups water 12 black tea bags MILK MIXTURE:  6 tablespoons half & half  6 tablespoons sweetened condensed milk ASSEMBLY:  6 cups ice, divided SPECIAL EQUIPMENT:  Wide-opening straw (4 straws, one per serving)")
                                .font(.headline)
                                .padding()
                                .transition(.slide)
                        }
                    }
                    .animation(.easeInOut, value: showText)
                }

            }
            
            struct ContentView_Previews: PreviewProvider {
                static var previews: some View {
                    ContentView()
                }
            }

#Preview {
    Amount()
}
