//
//  Home.swift
//  YesChefChallenge
//
//  Created by Sudowe, Yuki - Student on 9/18/24.
//

import SwiftUI

struct Home: View {
    var body: some View {
        ZStack {
            
            Image("Boba")
                .resizable()
            Text("Boba Recipe")
                .font(.largeTitle)
                .foregroundStyle(.white)
                .bold()
                .background(.mint)
               
        }

    }
}

#Preview {
    Home()
}
