//
//  ContentView.swift
//  YesChefChallenge
//
//  Created by Sudowe, Yuki - Student on 9/17/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {



            TabView {
                
                Home()
                    .tabItem {
                        Label("Home", systemImage: "house")
                    }
                Ingredients()
                    .tabItem {
                        Label("Ingredients", systemImage: "arrow.up.bin.fill")
                    }
                
                
                Instructions()
                    .tabItem {
                        Label("Instructions", systemImage: "clipboard.fill")
                    }
                
                Amount()
                    .tabItem {
                        Label("Amount", systemImage: "person.fill")
                    }
                }
                
            }
    }


#Preview {
    ContentView()
}
