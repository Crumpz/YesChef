//
//  Instructions.swift
//  YesChefChallenge
//
//  Created by Sudowe, Yuki - Student on 9/17/24.
//

import SwiftUI

struct Instructions: View {
    var body: some View {
        VStack {
            Text("Preparation")
                .font(.largeTitle)
            Text("Make the boba pearls:")
                .font(.title)
            Text("Add the water and muscovado sugar to a medium pan over medium-high heat. Cook until the sugar dissolves and the mixture comes to a boil, 3–4 minutes. Add a bit of the tapioca flour and cook, stirring constantly, until smooth. Add half of the remaining tapioca flour and stir vigorously until a sticky dough forms. Turn off the heat and add the remaining tapioca flour. Stir until the dough comes together in a ball (not all of the flour will be incorporated at this stage). Let cool slightly.")
            Text("Turn the dough out onto a clean surface. Knead until all of the flour is incorporated and the dough is smooth, adding more flour or water as needed if the dough is too sticky or too dry.")
            Text("Divide the dough into 2 portions. Roll the dough into long, thin ropes about ¼-inch (6.35 mm) thick, cutting in half crosswise if they get too long. Cut the ropes into ¼-inch (6.35 mm) pieces. Roll each piece into a ball and place in a bowl with a bit of tapioca flour. Dust the balls with the flour to prevent them from sticking to each other.")
            Text("Bring a large pot of water to a boil. Shake off any excess flour from the tapioca pearls, then add to the boiling water. Stir to separate the pearls, then reduce the heat to medium-low. Simmer gently, stirring occasionally, for about 20 minutes, until cooked through.")
            Text("Meanwhile, make the brown sugar syrup:")
                .font(.title)
            Text("Add the muscovado sugar and water to a small saucepan over medium heat. Cook until the sugar dissolves and the syrup reduces slightly, 5–7 minutes. Pour the syrup into a large heatproof bowl.")
            Text("Once the pearls have cooked through, drain and rinse with cold water. Add the pearls to the bowl with the brown sugar syrup and let sit for 30–60 minutes.")
            Text("Make the black tea:")
                .font(.title)
            Text("In a medium pot over high heat, combine the water and tea bags. Bring to a boil, then remove the pan from the heat and let the tea cool to room temperature.")
            Text("Make the milk mixture:")
                .font(.title)
            Text("In a small bowl or liquid measuring cup, whisk together the half-and-half and sweetened condensed milk until combined.")
            Text("Assemble the boba milk tea:")
                .font(.title)
            Text("Add about ⅓ cup (80 ml) boba pearls and brown sugar syrup to the bottom of each glass. Top with 1½ cups (225 grams) ice, then add ½ cup (240 ml) black tea and 3 tablespoons of the milk mixture. Stir with a wide-opening straw, then serve.")
            Text ("Enjoy!")
                .font(.largeTitle)
        }
        .padding()
        .background(.mint)
    }
}

#Preview {
    Instructions()
}
