//
//  Ingredients.swift
//  YesChefChallenge
//
//  Created by Sudowe, Yuki - Student on 9/17/24.
//

import SwiftUI

struct Ingredients: View {
    var body: some View {
        VStack {
            Text("BOBA PEARLS")
                .font(.title)
            Text ("BROWN SUGAR SYRUP")
                .font(.title)
            Text("BLACK TEA")
                .font(.title)
            Text("MILK MIXTURE")
                .font(.title)
        }
        .padding()
        .background(.mint)
    }
}
#Preview {
    Ingredients()
}
